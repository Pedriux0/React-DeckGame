//StAuth10244: I Juan Naranjo, 000895164 certify that this material is my original work. No other person's work has been used without due acknowledgement. I have not made my work available to anyone else.

import React, { useState } from "react";
import "./App.css";
import Card from "./components/Card";
import Controls from "./components/Controls";

// Suits and values for a standard deck of cards
const suits = ["♥", "♦", "♣", "♠"];
const values = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];

// Function to generate a deck of 52 cards
const generateDeck = () => {
  const deck = [];
  for (let suit of suits) {
    for (let value of values) {
      deck.push({ suit, value });
    }
  }
  return deck;
};

// Function to shuffle a deck (Fisher-Yates algorithm)
const shuffleDeck = (deck) => {
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
};

// Dealer phrases for fun
const dealerPhrases = [
  "Press Your Bet",
  "Bust",
  "Snake Eyes",
  "Winner, Winner, Chicken Dinner",
  "Hit Me",
];

const App = () => {
  const [deck, setDeck] = useState(shuffleDeck(generateDeck()));
  const [selectedCards, setSelectedCards] = useState([]);
  const [pickedCard, setPickedCard] = useState(null);
  const [dealerPhrase, setDealerPhrase] = useState("");

  // Deal a specific number of cards
  const dealCards = (num) => {
    
    if (deck.length < num) {
      alert("No more cards");
      return;
    }

    // Return all selected cards 
    const newDeck = [...deck, ...selectedCards];
    const shuffledDeck = shuffleDeck(newDeck);

    // Deal new cards
    const dealtCards = shuffledDeck.splice(0, num);
    setSelectedCards(dealtCards);
    setDeck(shuffledDeck);

    // Set a random dealer phrase
    setDealerPhrase(dealerPhrases[Math.floor(Math.random() * dealerPhrases.length)]);
  };

  // Reset the game
  const resetDeck = () => {
    setDeck(shuffleDeck(generateDeck()));
    setSelectedCards([]);
    setPickedCard(null);
    setDealerPhrase("");
  };

  // Select a card
  const selectCard = (index) => {
    if (pickedCard === null) {
      setPickedCard(index);
    } else {
      let newCards = [...selectedCards];
      [newCards[pickedCard], newCards[index]] = [newCards[index], newCards[pickedCard]];
      setSelectedCards(newCards);
      setPickedCard(null);
    }
  };

  //  Remove
  const tossCard = () => {
    if (pickedCard !== null) {
      setSelectedCards(selectedCards.filter((_, i) => i !== pickedCard));
      setPickedCard(null);
    }
  };

  // Shuffle selected cards
  const regroupCards = () => {
    setSelectedCards(shuffleDeck([...selectedCards]));
  };

  // Add a wildcard (random card)
  const addWildcard = () => {
    const randomSuit = suits[Math.floor(Math.random() * suits.length)];
    const randomValue = values[Math.floor(Math.random() * values.length)];

    const newCard = { suit: randomSuit, value: randomValue };

    // Add the wildcard 
    setSelectedCards([...selectedCards, newCard]);
    setDeck(deck.slice(1)); // Reduce the deck by 1 card
  };

  // Deck click handler
  const handleDeckClick = () => {
    if (deck.length === 0) {
      return; // If there are no cards left in the deck, do nothing
    }

    const newCard = deck[0]; // Take the top card from the deck
    const newDeck = deck.slice(1); // Remove the top card 

    setSelectedCards((prevCards) => [...prevCards, newCard]); // Add the new card 
    setDeck(newDeck); // Update the deck 
  };

  return (
    <div className="app">
      <h1>Deck Game</h1>
      {dealerPhrase && <div className="dealer-phrase">{dealerPhrase}</div>}

      {/* Deck click area */}
      <div
        className={`deck ${deck.length === 0 ? "empty" : ""}`}
        onClick={handleDeckClick}
      >
        {deck.length > 0 ? `Deck (${deck.length} cards)` : "No cards remaining"}
      </div>

      {/* Controls */}
      <Controls
        dealCards={dealCards}
        resetDeck={resetDeck}
        tossCard={tossCard}
        regroupCards={regroupCards}
        addWildcard={addWildcard}
      />

      {/* Selected cards area */}
      <div className="selected-cards">
        {selectedCards.map((card, index) => (
          <Card
            key={index}
            suit={card.suit}
            value={card.value}
            onClick={() => selectCard(index)}
            selected={pickedCard === index}
          />
        ))}
      </div>
    </div>
  );
};

export default App;