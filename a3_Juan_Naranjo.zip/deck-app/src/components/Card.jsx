//StAuth10244: I Juan Naranjo, 000895164 certify that this material is my original work. No other person's work has been used without due acknowledgement. I have not made my work available to anyone else.

import React from "react";
import "../App.css";

/**
 * Card Component: Displays a single card with its suit and value.
 * @param {string} suit - The suit of the card (♥, ♦, ♣, ♠).
 * @param {string} value - The value of the card (A, 2-10, J, Q, K).
 * @param {function} onClick - Function to handle card selection.
 * @param {boolean} selected - Whether the card is currently selected.
 */
const Card = ({ suit, value, onClick, selected }) => {
  // Determine the color of the card based on its suit
  const getColor = () => {
    if (suit === "♥" || suit === "♦") return "red";
    return "black";
  };

  return (
    <div
      className={`card ${selected ? 'selected' : ''}`}
      onClick={onClick}
      style={{ color: getColor() }}
    >
      <div className="card-value">{value}</div>
      <div className="card-suit">{suit}</div>
    </div>
  );
};

export default Card;