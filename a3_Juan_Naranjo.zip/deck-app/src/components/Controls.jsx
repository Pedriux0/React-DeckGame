//StAuth10244: I Juan Naranjo, 000895164 certify that this material is my original work. No other person's work has been used without due acknowledgement. I have not made my work available to anyone else.

import React from "react";

/**
 * Controls Component: Contains buttons for deck actions.
 * @param {function} dealCards - Function to deal a number of cards.
 * @param {function} resetDeck - Function to reset the deck.
 * @param {function} tossCard - Function to toss a selected card.
 * @param {function} regroupCards - Function to shuffle selected cards.
 * @param {function} addWildcard - Function to add a wildcard.
 */
const Controls = ({ dealCards, resetDeck, tossCard, regroupCards, addWildcard }) => {
  return (
    <div className="controls">
      <button onClick={() => dealCards(5)}>Deal 5</button>
      <button onClick={() => dealCards(7)}>Deal 7</button>
      <button onClick={resetDeck}>Reset</button>
      <button onClick={tossCard}>Toss</button>
      <button onClick={regroupCards}>Regroup</button>
      <button onClick={addWildcard}>Wildcard</button>
    </div>
  );
};

export default Controls;
